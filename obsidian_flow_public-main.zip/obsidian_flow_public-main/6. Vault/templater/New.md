---
aliases: []
created: <% tp.file.creation_date("YYYY-MM-DD HH:mm:ss") %>
progress: raw
blueprint: []
impact: 
urgency: 
tags: []
category: []
---
