---
aliases:
  - Mindmap các nội dung chính về sử dụng Github cơ bản
created: 2024-09-22
progress: medium
blueprint:
  - - Python for the Community
impact: 3
urgency: 
tags: 
category: 
mindmap-plugin: basic
---


# Github

## Tìm kiếm
- Lọc kết quả

## Xem chi tiết  kết quả
- Phân loại
	- Repo
		- Package (gói phần mềm)
		- Script (file Python lẻ)
	- Gist
		- Jupyter Notebook
		- Script (file Python lẻ)
- Hành động
	- Tài trợ (Sponsor)
	- Pin (Ghim)
	- Watch (theo dõi)
	- Star (yêu thích)
	- Download
	- Sửa đổi mã (Codespace)

## Cài đặt & sử dụng
- pip install
- cli command
- python code

## Sao chép & sửa đổi mã nguồn
- clone
- fork

## Đóng góp
- fork
- pull request
- push