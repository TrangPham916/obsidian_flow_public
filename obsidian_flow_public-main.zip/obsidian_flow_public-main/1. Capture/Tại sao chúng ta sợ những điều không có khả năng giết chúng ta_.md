---
aliases: 
created: 2024-09-29 16:49:00
progress: raw
blueprint:
  - "[[../4. Blueprint/Reading Challenges|Reading Challenges]]"
impact: 
urgency: 
tags: 
category: 
source:
  - "[[../6. Vault/bookshelf/Risk Savvy - How to Make Good Decisions|Risk Savvy: How to Make Good Decisions]]"
---

- **Sợ hãi là phản ứng sinh tồn, nhưng cũng có thể khiến chúng ta sợ hãi những điều sai.**
    - Hãy nhớ rằng học hỏi từ kinh nghiệm cá nhân không phải lúc nào cũng an toàn. Bắt chước xã hội và sự chuẩn bị sinh học là những cơ chế giúp chúng ta học cách sợ hãi một cách an toàn mà không cần trải nghiệm trực tiếp.
- **Chúng ta dễ bị thao túng bởi nỗi sợ hãi.**
    - Cảnh giác với việc truyền thông khai thác nỗi sợ hãi về những sự kiện hiếm hoi nhưng gây nhiều thiệt hại (dread risks) để tăng cường sự chú ý và ảnh hưởng.
- **Kiểm soát nội tại là chìa khóa để vượt qua nỗi sợ hãi.**
    - Tập trung vào việc phát triển kỹ năng, giá trị đạo đức, và những mục tiêu nội tại sẽ giúp ta kiểm soát cảm xúc và giảm bớt lo lắng.
- **Lắng nghe trực giác, bởi vì nó có thể là một nguồn thông tin quý giá.**
    - Trực giác không phải là cảm xúc bốc đồng, mà là một dạng trí tuệ tiềm thức dựa trên kinh nghiệm và các quy tắc đơn giản. Hãy tin tưởng vào trực giác của mình trong việc đưa ra quyết định.