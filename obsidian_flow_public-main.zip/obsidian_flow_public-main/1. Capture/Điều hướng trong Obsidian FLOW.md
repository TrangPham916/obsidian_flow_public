---
aliases: []
created: 2024-09-29 17:11:00
progress: raw
blueprint: []
impact: 
urgency: 
tags: []
category: []
---

> [!important]
> Hãy tự do ghi chú lại các ý tưởng bất chợt, không quá cố gắng hoàn hảo mà cho chúng có cơ hội được hoàn thiện trong suốt vòng đời của mình.

# Sử dụng phím tắt

Xem thêm: [Hệ thống phím tắt trong Obsidian FLOW](../5.%20Exhibit/FLOW%20&%20PKM/Hệ%20thống%20phím%20tắt%20trong%20Obsidian%20FLOW.md)

# Sử dụng giao diện đồ hoạ
- Thanh công cụ Ribbon
![](../6.%20Vault/attachments/obsidian_flow_ribbon_navigation.png)

## Quản lý nhiệm vụ cần làm

> [!todo]
> Sử dụng Tasks Calendar Wrapper plugin để quản lý nhiệm vụ cần làm
> Sử dụng Reminder plugin để đặt nhắc nhở, gõ `(@` để kích hoạt giao diện chọn ngày, giờ nhắc nhở. Click vào "Focus On Today" sẽ hiện ra dòng thời gian các nhiệm vụ như trong hình.


![](../6.%20Vault/attachments/Pasted%20image%2020240929172844.png)

## Home

![](../6.%20Vault/attachments/Pasted%20image%2020240929173717.png)

## Điều hướng trong bài viết - Floating TOC

![](../6.%20Vault/attachments/floating_toc.png)