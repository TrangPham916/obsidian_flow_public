---
aliases: []
created: 2024-09-25 15:25:00
progress: raw
blueprint: []
impact: 
urgency: 
tags: []
category: []
---
## Cấu hình chế độ xem bảng (Table)

### Hiển thị nội dung markdown

![](../6.%20Vault/attachments/obsidian_project_configure_field.png)

![](../6.%20Vault/attachments/obsidian_project_enable_rich_text_formating.png)

## Thiết lập chế độ xem bảng Kanban (Board)

![](../6.%20Vault/attachments/choose_progress_properties_as_status_field.png)

![](../6.%20Vault/attachments/Pasted%20image%2020240925153203.png)